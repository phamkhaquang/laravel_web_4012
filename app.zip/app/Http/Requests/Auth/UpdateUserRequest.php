<?php

namespace App\Http\Requests\Auth;

use Illuminate\Foundation\Http\FormRequest;

class UpdateUserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required|min:2',
            'birthday' => 'required',
            'email' => 'required|email',
            'phone' => 'required|between:10,11',
        ];
    }
    public function messages()
    {
        return [
        'name.required' => 'Tên không được để trống',
        'name.min' => 'Tên không được nhỏ hơn 2 ký tự',
        'birthday.required' => 'Ngày sinh không được để trống',
        'email.required' => 'Email không được để trống',
        'email.email' => 'Email bạn vừa nhập không đúng định dạng',
        'phone.required' => 'SĐT không được để trống',
        'phone.between' => 'SĐT phải là 10 hoặc 11 số',
        ];
    }
}

