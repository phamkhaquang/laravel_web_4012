<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Category;
class PageController extends Controller
{
    function index()
    {
    	$posts = Post::with('user')->with('category')->paginate(5);
    	return view('page.index',['posts' => $posts]);
    }
    function singlePost($id)
    {
    	$post = Post::find($id);
    	return view('page.single',['post'=>$post]);
    }
    function PostCategory($id)
    {
    	$categories = Category::all();
    	$category = Category::find($id);
    	return view('page.category',compact('categories','category'));
    }
}
